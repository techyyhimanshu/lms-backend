export const baseurl = "https://sandbox.cashfree.com/pg/lrs"
export const baseurl2 = "https://api.cashfree.com/pg/lrs"
export const baseurlcpay = "https://uatapi.cipherpay.co.in/api/"

