export default class FormType {
    public id?: number;
    public eflexId?: string;
    public formType?: string;

    public FormType() {
        this.id = 0,
            this.eflexId = '',
            this.formType = ''
    }
}
