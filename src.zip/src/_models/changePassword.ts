export interface ChangePassword {
    userId: string;
    oldPassword: string;
    newPassword: string;
}