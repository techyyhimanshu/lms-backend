export default {
    encryption_key:'79c14c49b186aab0a45646280a474bb7',
    iv:'5fda51d0f20b508b',
    p_user_type:'getlogIN',
    user_list: "select * from cit_registeruser",
    add_new_student:'ADDNEWSTUDENT',
    add_student:"INSERT INTO STUDENT_API (authToken, candidateId, candidateName, MOBILE, applicationNo, EMAIL,  DOB, locationCode, LOCATION, STATE, ZONE, aadhaarNo, panNo, urnNo, REGDATE) VALUES  ('werw', 'rwer', 'wer', '9910788463', 'cinod', 'vinod@gmail.com', 'test', '11224555',  'sdfsd', 'sdfs', 'sdf', '3543535', '35gdd', '3553533', SYSDATE)",
    p_user_master:'p_user_master',
    p_change_user_password:'p_change_user_password'
};